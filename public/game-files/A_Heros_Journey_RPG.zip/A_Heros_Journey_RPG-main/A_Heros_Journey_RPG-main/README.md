# RPG: A Hero's Journey

## About
This is a small rpg game made with RPG Maker VX Ace.
It is about a hero trying to defeat a evil boss
and save his or her town.

## Running the Game
To play the game you have to go into the Project1 folder
and run the Game.exe file.

## Purpose
This repository serves as a way to catalogue the process
of making a rpg game and advancing my skills in
the RPG Maker VX Ace game engine.
